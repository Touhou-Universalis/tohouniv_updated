NDefines.NFrontend.CAMERA_LOOKAT_X = 5358.0
NDefines.NFrontend.CAMERA_LOOKAT_Z = 1214.0
NDefines.NFrontend.CAMERA_LOOKAT_SETTINGS_X = 5358.0
NDefines.NFrontend.CAMERA_LOOKAT_SETTINGS_Z = 1214.0

NDefines.NFrontend.CAMERA_START_X = 5358.0
NDefines.NFrontend.CAMERA_START_Y = 700.0
NDefines.NFrontend.CAMERA_START_Z = 1164.0

NDefines.NFrontend.CAMERA_END_X = 5358.0
NDefines.NFrontend.CAMERA_END_Y = 800.0
NDefines.NFrontend.CAMERA_END_Z = 1164.0

NDefines.NFrontend.FRONTEND_POS_X = 5358.0
NDefines.NFrontend.FRONTEND_POS_Y = 800.0
NDefines.NFrontend.FRONTEND_POS_Z = 1164.0
NDefines.NFrontend.FRONTEND_LOOK_X = 5358.0
NDefines.NFrontend.FRONTEND_LOOK_Z = 1180.0
NDefines.NFrontend.SETTINGS_POS_X = 5358.0
NDefines.NFrontend.SETTINGS_POS_Y = 551.0
NDefines.NFrontend.SETTINGS_POS_Z = 978.0
NDefines.NFrontend.SETTINGS_LOOK_X = 5398.0
NDefines.NFrontend.SETTINGS_LOOK_Z = 1160.0
NDefines.NFrontend.MP_OPTIONS_POS_X = 5358.0
NDefines.NFrontend.MP_OPTIONS_POS_Y = 922.0
NDefines.NFrontend.MP_OPTIONS_POS_Z = 700.0
NDefines.NFrontend.MP_OPTIONS_LOOK_X = 5358.0
NDefines.NFrontend.MP_OPTIONS_LOOK_Z = 800.0

NDefines.NAI.CALL_ACCEPTANCE_COALITION_VS_SUBJECT = 0

--NDefines.NCountry.ESTATE_PRIVILEGES_MAX_CONCURRENT = 8		-- Max. number of privileges active at the same time
--NDefines.NEconomy.MAX_BUILDING_SLOTS = 16
NDefines.NCountry.MAX_EXTRA_PERSONALITIES = 3				   -- Number of personalities that can be gained except the one you get when turning 15.
NDefines.NCountry.YEARS_PER_EXTRA_PERSONALITY = 10			  -- Number of years between new personalities after first one.