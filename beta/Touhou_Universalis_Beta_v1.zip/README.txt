This mod is the developer test version. Every change made in this mod is not guaranteed to be implemented in the final version of the update. 
To test this version you have to move the tohouniv_updated_dev_version.mod file and tohouniv_updated_dev_version directory to your EU4 mod path, which should look like this:

C:\Users\[Your PC Username]\Dokumente\Paradox Interactive\Europa Universalis IV\mod

After moving these files to the correct location you must only update tohouniv_updated_dev_version.mod file by replacing the path in quotation marks with the mod path.

Make sure that all "\" are replaced with "/" because the launcher has troubles reading the "\". (Don't ask me why, it just has these troubles.)

Then make sure that the mod is loaded by pressing the "Reload Installed Mods" in the "All installed mods" section. If you can't find the mod then check if description and the .mod file have the correct /.

If it still does not load you can do a workaround by creating your own mod (press "Mod Tools" in the "All installed mods" section) and copy all the files (except for the descriptor.mod) from this mod and paste them into your own mod.

Make sure the mod is also present in your playset.